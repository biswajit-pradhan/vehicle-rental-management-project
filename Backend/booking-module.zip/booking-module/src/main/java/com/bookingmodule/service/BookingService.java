package com.bookingmodule.service;

public class BookingService {

}
